from flask.views import MethodView
from flask import jsonify, request
import time

class LoginUserControllers(MethodView)
    
    def post(self):
        pass


class RegisterUserControllers(MethodView)

    def post(self)
        pass

    def get(self)
        pass

class RecoberyUserControllers(MethodView)

    def post(self)
        pass

    def get(self)
        pass
class AdminControllers(MethodView)

    def post(self)
        pass

    def get(self)
        pass

class AtractivosUserControllers(MethodView)

    def post(self)
        pass

    def get(self)
        pass