from controllers import LoginUserControllers,RegisterUserControllers,RecoberyUserControllers,AdminControllers,AtractivosUserControllers

user = {
    "Login_User": "direccion", "LoginUserController" : LoginUserControllers.as_view("login"),
    "Register_User": "direccion", "RegisterUserController" : RegisterUserControllers.as_view("Register"),
    "Recobery_User": "direccion", "RecoberyUserController" : RecoberyUserControllers.as_view("Recobery"),
    "Admin": "direccion", "AdminController" : AdminControllers.as_view("Admin"),
    "Atractivos_User": "direccion", "AtractivosUserController" : AtractivosUserControllers.as_view("Atractivos")
}