from app import app

PORT = 5000
DEBUG = True

app.run(port=PORT, debug=DEBUG)
