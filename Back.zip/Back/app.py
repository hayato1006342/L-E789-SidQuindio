from flask import Flask
from routes import *
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

app.add_url_rule(user["Login_User"],view_func=user["login_user_controller"])
app.add_url_rule(user["Register_User"],view_func=user["register_user_controller"])
app.add_url_rule(user["Recobery_User"],view_func=user["recobery_user_controller"])
app.add_url_rule(user["Admin"],view_func=user["admin_controller"])
app.add_url_rule(user["Atractivos_User"],view_func=user["atractivos_user_controller"])